package tads.eaj.ufrn.segundaprova.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import tads.eaj.ufrn.segundaprova.R
import tads.eaj.ufrn.segundaprova.adapters.TaskAdapter

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?{

        var adapter = TaskAdapter()

        val layout = LinearLayoutManager(parentFragment?.context, LinearLayoutManager.VERTICAL, false)

        return inflater.inflate(R.layout.fragment_home, container, false)
    }
}